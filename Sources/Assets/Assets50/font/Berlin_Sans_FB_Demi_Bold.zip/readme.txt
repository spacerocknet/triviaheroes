Congratulations, you have successfully downloaded font file! 

This font was downloaded from http://www.FontIneed.com � the biggest collection of
quality fonts from award winning font designers.

How to install this font on your computer?

Close any open Windows applications, such as Microsoft Word or Microsoft Outlook�.

For Windows users:

- Copy the .TTF file(s) into the default Windows font folder 
  (usually C:\WINDOWS\FONTS)

For Linux users:

- Copy the font file(s) to /USR/SHARE/FONTS

IMPORTANT:

When you install a new font on a computer, remember that it will only work with the
computer you've installed it on.


How to install this font?
Step 1 Download your favourite free fonts.
Step 2 Unzip the font file.
Step 3 Copy the .ttf, .otf or .fon extension file.
Step 4 Paste them in your computer's font folder.

Windows
C:\Windows\Fonts or C:\WINNT\Fonts
(can be reached as well by the Start Menu > Control Panel > Appearance and Themes > Fonts).

Mac OS X
/Library/Fonts (for all users),
or /Users/Your_username/Library/Fonts (for you only).
If your OS includes the Font Book, you can as well double-click on a font file, then a preview pops with an "Install font" button.

Linux
Copy the font files (.ttf or .otf) to fonts:/// in the File manager.

--------------------------------------------
http://www.FontIneed.com � the biggest collection of quality fonts from award winning font designers.